#!/bin/bash
# Cleans directory

rm -fr *.tfstate
rm -fr *.tfstate.*
rm -fr *.tfplan
rm -fr *.zip
rm -fr Dockerrun.aws.json=